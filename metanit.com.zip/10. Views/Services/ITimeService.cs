﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace _10._Views.Services
{
    public interface ITimeService
    {
        string GetTime();
    }
}
